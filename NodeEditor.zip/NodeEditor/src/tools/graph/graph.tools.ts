
export const useGraphManagement = () => {


}

export const consumeGraph = () => {

}