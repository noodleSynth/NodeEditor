export interface GraphLink{
  nodeIdA: string,
  nodeIdB: string,
}